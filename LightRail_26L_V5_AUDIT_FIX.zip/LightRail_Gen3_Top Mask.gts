G04 LightRail Gen3 - F_Mask*
G04 Date: 2026-03-06 18:46:11*
%MOMM*%G04 Units: Millimeters*
%FSLAX36Y36*%G04 Format: 3.6 Absolute*
%ADD10C,0.100000*%G04 Trace Aperture*
%ADD11C,0.500000*%G04 Pad/Via Aperture*
%ADD12C,0.200000*%G04 Outline Aperture*
%LPD*%G04 Layer Polarity: Dark*
G01*
D10*
D12*
X0Y0D02*
X106680000Y0D01*
X106680000Y111150000D01*
X0Y111150000D01*
X0Y0D01*
D10*
M02*
