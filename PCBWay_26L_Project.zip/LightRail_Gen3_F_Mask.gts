G04 LightRail Gen3 - F_Mask*
G04 Date: 2026-03-06 08:46:40*
%MOMM*%G04 Units: Millimeters*
%FSLAX36Y36*%G04 Format: 3.6 Absolute*
G01*
D10*
M02*
