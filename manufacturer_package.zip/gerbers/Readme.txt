TFLN PHOTONIC MODULATOR - 12-LAYER PCB DESIGN
=============================================
Generated: 2026-01-31 23:31:45
Stackup Configuration:
  L1: Top Signal (RF)
  L2: Ground
  L3: Signal (Stripline)
  L4: Ground
  L5: Signal (Stripline)
  L6: Ground
  L7: Power (+3.3V)
  L8: Ground
  L9: Power (+1.8V)
  L10: Signal (Control)
  L11: Ground
  L12: Bottom Signal
